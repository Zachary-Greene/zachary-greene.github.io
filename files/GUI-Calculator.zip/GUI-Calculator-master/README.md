# GUI Based Calculator

This program is a GUI based calculator with basic functions (+, -, *, /)
You can do basic maths with this program. Included within the repository is an exe, a
readme file, a license file and a python file

## Prerequisites
To get the .py file working, you need to download Python 3 or above.
To download Python go to the [Python](https://www.python.org/downloads/) web page and click the yellow button
under 'Download the latest version for Windows' or select your OS under the yellow button.

## Built With
The modules used in this program are Tkinter and the inbuilt System/Sys libraries

## License
See LICENSE.md
