themeOptions = ["Light Mode", "Dark Mode"]

def writeData():
    pass